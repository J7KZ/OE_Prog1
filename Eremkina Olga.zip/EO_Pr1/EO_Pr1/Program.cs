﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EO_Pr1
{
    class Program
    {
        static void Main(string[] args)
        {
            int s;
            Console.Write("Введите число элементов массива: ");
            s = int.Parse(Console.ReadLine());
            int[] A = new int[s];
            InputArr(A);
            SortArr(A);
            PrintArr(A);
        }
        public static void InputArr(int[] A)
        {

            Random rnd = new Random();
            for (int i = 0; i < A.Length; i++)
            {
                A[i] = rnd.Next(1, 100);
            }
        }
        public static void SortArr(int[] A)
        {
            int t;
            for (int i = 0; i < A.Length - 1; i++)
            {
                for (int j = i + 1; j < A.Length; j++)
                {
                    if (A[i] > A[j])
                    {
                        t = A[i];
                        A[i] = A[j];
                        A[j] = t;
                    }
                }
            }
        }
        public static void PrintArr(int[] A)
        {
            Console.WriteLine("Элементы массива");
            for (int i = 0; i < A.Length; i++)
            {
                Console.WriteLine("A[{0}] = {1}", i, A[i]);
            }
            Console.ReadLine();
        }

    }
}
